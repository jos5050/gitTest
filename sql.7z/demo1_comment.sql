CREATE DATABASE  IF NOT EXISTS `demo1` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `demo1`;
-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: demo1
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `boardid` int NOT NULL,
  `content` varchar(45) DEFAULT NULL,
  `writer` varchar(45) NOT NULL,
  `date` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (1,1,'11','11','11'),(2,2,'3','4','5'),(5,12,'ㅁㄴㅇㄻㄴㅇㄹ','testUser','2020-03-26 10:55:02'),(6,12,'ㄴㅇㅀ','testUser','2020-03-26 10:55:39'),(7,12,'111','testUser','2020-03-26 10:56:20'),(8,12,'111','testUser','2020-03-26 10:56:42'),(11,4,'안녕','test','2020-03-26 14:54:32'),(12,4,'ㅁㄶㅇㅁㄴㅇㅎㅁㄴ','test','2020-03-26 14:54:35'),(15,5,'c','test','2020-03-26 14:57:11'),(16,5,'ㅋㅌㅊㅍㅋㅌㅊㅍ','test','2020-03-26 14:57:13'),(24,4,'asfasffafas','testuser','2020-03-26 18:54:04'),(25,4,'ㅁㄹㄴㅇㅀ','testuser','2020-03-27 14:32:02'),(26,14,'bvnvbn','testuser','2020-03-30 13:02:38'),(27,14,'fghfgh','testuser','2020-03-30 13:02:39'),(28,14,'fghfghㅁㄴㅇㄻㄴㅇㄹ','testuser','2020-03-30 13:02:41'),(29,15,'1','testuser','2020-03-30 15:56:33'),(30,15,'1','testuser','2020-03-30 15:56:35'),(31,15,'1','testuser','2020-03-30 15:56:36'),(32,15,'1','testuser','2020-03-30 15:56:37'),(33,15,'1','testuser','2020-03-30 15:56:38'),(34,15,'1','testuser','2020-03-30 15:56:39'),(35,15,'1','testuser','2020-03-30 15:56:40');
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 18:17:14
